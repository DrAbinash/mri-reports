/* eslint-disable react/no-unescaped-entities */
'use client';

import { useState, useEffect } from 'react';
import type { MriReport } from '@/lib/store';
import { Button } from '@/components/ui/button';
import {
  ArrowLeft, Pencil, Trash2, Printer, Download,
} from 'lucide-react';
import { format } from 'date-fns';

interface HospitalInfo {
  hospitalName: string;
  tagline: string | null;
  address: string | null;
  phone: string | null;
  website: string | null;
  email: string | null;
  logoUrl: string | null;
  radiologistName: string | null;
  radiologistQualification: string | null;
  radiologistRegNumber: string | null;
  accreditation: string | null;
  accreditationNumber: string | null;
  footerMessage: string;
  reportHeaderColor: string;
  // Layout
  reportLayout: string;
  showTechnique: boolean;
  showComparison: boolean;
  showClinicalInfo: boolean;
  showSignature: boolean;
  showFooterMessage: boolean;
  showAccreditation: boolean;
  patientColumns: string;
  impressionStyle: string;
  headerStyle: string;
}

interface Props {
  report: MriReport;
  onBack: () => void;
  onEdit: () => void;
  onDelete: () => void;
}

export default function ReportViewer({ report, onBack, onEdit, onDelete }: Props) {
  const [hospital, setHospital] = useState<HospitalInfo | null>(null);

  useEffect(() => {
    fetch('/api/reports/hospital-settings')
      .then(r => r.json())
      .then(d => setHospital(d.settings))
      .catch(() => {});
  }, []);

  const handlePrint = () => window.print();

  const getReportCSS = () => {
    // Extract all report-related CSS rules from the current document
    const sheets = document.styleSheets;
    let css = '';
    for (let i = 0; i < sheets.length; i++) {
      try {
        const rules = sheets[i].cssRules;
        for (let j = 0; j < rules.length; j++) {
          const rule = rules[j] as CSSStyleRule;
          if (
            rule.selectorText &&
            (rule.selectorText.includes('report-') || rule.selectorText.includes('no-print') || rule.selectorText.includes('@page') || rule.selectorText.includes('@media print'))
          ) {
            css += rule.cssText + '\n';
          }
        }
      } catch {
        // Cross-origin stylesheet — skip
      }
    }
    return css;
  };

  const handleDownloadPdf = () => {
    const el = document.getElementById('report-printable');
    if (!el) return;

    const reportHTML = el.innerHTML;
    const css = getReportCSS();
    const fileName = `${report.patientName || 'report'}_${report.bodyRegion || 'mri'}_${report.studyDate ? format(new Date(report.studyDate), 'yyyy-MM-dd') : 'report'}.pdf`;

    const html = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>MRI Report — ${report.patientName || 'Patient'}</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  @page { size: A4 portrait; margin: 8mm; }
  html, body { background: white; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
  ${css}
</style>
</head>
<body>
<div class="report-page" data-layout="${layout}">
${reportHTML}
</div>
<script>
  window.addEventListener('load', () => {
    setTimeout(() => window.print(), 400);
  });
</script>
</body>
</html>`;

    const blob = new Blob([html], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const win = window.open(url, '_blank');
    if (win) {
      // Write directly for better compatibility
      win.document.open();
      win.document.write(html);
      win.document.close();
      URL.revokeObjectURL(url);
    }
  };

  const h = hospital || {
    hospitalName: 'MRI Report Center',
    tagline: null, address: null, phone: null, website: null, email: null, logoUrl: null,
    radiologistName: null, radiologistQualification: null, radiologistRegNumber: null,
    accreditation: null, accreditationNumber: null,
    footerMessage: 'Thank you for choosing our services.',
    reportHeaderColor: '#1e3a5f',
    reportLayout: 'classic', showTechnique: true, showComparison: true, showClinicalInfo: true,
    showSignature: true, showFooterMessage: true, showAccreditation: true,
    patientColumns: '3', impressionStyle: 'bordered', headerStyle: 'full',
  };

  const c = h.reportHeaderColor || '#1e3a5f';
  const layout = h.reportLayout || 'classic';
  const cols = h.patientColumns || '3';

  const findingLines = report.findings.split('\n').filter(l => l.trim()).map(l => l.replace(/^[-•*]\s*/, '').trim());
  const impressionLines = report.impression.split('\n').filter(l => l.trim()).map(l => l.replace(/^[-•*\d.)]+\s*/, '').trim());

  // Compact layout renders everything in one card without heavy borders
  const isCompact = layout === 'compact';
  // Modern layout uses thinner styling
  const isModern = layout === 'modern';
  const renderFindings = () => {
    if (isCompact) {
      return (
        <div style={{ fontSize: '9pt', lineHeight: '1.5' }}>
          <p style={{ fontWeight: 700, color: '#374151', marginBottom: 3 }}>FINDINGS:</p>
          {findingLines.map((line, i) => (
            <p key={i} style={{ margin: '0 0 2px 12px', paddingLeft: 0 }}>{line}</p>
          ))}
        </div>
      );
    }
    return (
      <div className="report-section">
        <h3 className="report-section-heading">
          MRI {report.bodyRegion.toUpperCase()} FINDINGS
        </h3>
        <ul className="report-findings-list">
          {findingLines.map((line, i) => (
            <li key={i} className="report-finding-item">
              <span className="report-bullet" style={{ backgroundColor: c }} />
              <span className="report-finding-text">{line}</span>
            </li>
          ))}
        </ul>
      </div>
    );
  };

  const renderImpression = () => {
    if (isCompact) {
      return (
        <div style={{ fontSize: '9pt', fontWeight: 700, color: '#111', marginTop: 6, lineHeight: '1.5' }}>
          <p style={{ marginBottom: 2 }}>IMPRESSION:</p>
          {impressionLines.map((line, i) => (
            <p key={i} style={{ margin: '0 0 1px 12px' }}>{i + 1}. {line}</p>
          ))}
        </div>
      );
    }

    if (h.impressionStyle === 'underlined') {
      return (
        <div className="report-section">
          <h3 className="report-section-heading">
            IMPRESSION
          </h3>
          <div style={{ borderBottom: `2px solid ${c}`, paddingBottom: 2, marginBottom: 4 }}>
            <ol className="report-impression-list">
              {impressionLines.map((line, i) => (
                <li key={i} className="report-impression-item" style={{ color: '#111' }}>{line}</li>
              ))}
            </ol>
          </div>
        </div>
      );
    }

    if (h.impressionStyle === 'plain') {
      return (
        <div className="report-section">
          <h3 className="report-section-heading">
            IMPRESSION
          </h3>
          <div style={{ fontSize: '10pt', fontWeight: 600, color: '#111', lineHeight: 1.6 }}>
            {impressionLines.map((line, i) => (
              <p key={i} style={{ margin: '0 0 3px 0' }}>{i + 1}. {line}</p>
            ))}
          </div>
        </div>
      );
    }

    // Default: bordered
    return (
      <div className="report-impression-box" style={{ borderLeftColor: c, backgroundColor: isModern ? 'transparent' : '#f0f4f8' }}>
        <h3 className="report-impression-heading">IMPRESSION</h3>
        <ol className="report-impression-list">
          {impressionLines.map((line, i) => (
            <li key={i} className="report-impression-item">{line}</li>
          ))}
        </ol>
      </div>
    );
  };

  return (
    <>
      {/* Screen-only toolbar */}
      <div className="flex items-center gap-2 no-print mb-4 flex-wrap">
        <Button variant="ghost" onClick={onBack} className="gap-2">
          <ArrowLeft className="w-4 h-4" /> Back
        </Button>
        <div className="flex-1" />
        <Button variant="outline" size="sm" onClick={handlePrint} className="gap-2">
          <Printer className="w-4 h-4" /> Print
        </Button>
        <Button variant="outline" size="sm" onClick={handleDownloadPdf} className="gap-2">
          <Download className="w-4 h-4" /> Download PDF
        </Button>
        <Button variant="outline" size="sm" onClick={onEdit} className="gap-2">
          <Pencil className="w-4 h-4" /> Edit
        </Button>
        <Button variant="outline" size="sm" onClick={onDelete} className="gap-2 text-destructive hover:text-destructive">
          <Trash2 className="w-4 h-4" /> Delete
        </Button>
      </div>

      {/* ========== REPORT PAGE ========== */}
      <div className="report-page" id="report-printable" data-layout={layout}>

        {/* === HEADER === */}
        {isCompact ? (
          // Compact: single line header
          <div style={{ padding: '8px 20px', borderBottom: `2px solid ${c}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              {h.logoUrl && <img src={h.logoUrl} alt="" style={{ height: 28, width: 28, objectFit: 'contain' }} />}
              <span style={{ fontSize: '12pt', fontWeight: 700, color: '#111', letterSpacing: '0.5px' }}>{h.hospitalName.toUpperCase()}</span>
            </div>
            <div style={{ fontSize: '8pt', color: '#6b7280' }}>
              {report.modality} {report.bodyRegion} — {report.studyType}
            </div>
          </div>
        ) : isModern ? (
          // Modern: thin line header
          <div style={{ padding: '8px 28px', borderBottom: `2px solid ${c}` }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              {h.logoUrl && <img src={h.logoUrl} alt="" style={{ height: 32, width: 32, objectFit: 'contain' }} />}
              <div>
                <span style={{ fontSize: '13pt', fontWeight: 700, color: '#111', letterSpacing: '0.5px' }}>{h.hospitalName.toUpperCase()}</span>
                {h.tagline && <span style={{ fontSize: '8pt', color: '#6b7280', letterSpacing: '1px', marginLeft: 10 }}>{h.tagline}</span>}
              </div>
              <div style={{ fontSize: '8pt', color: '#6b7280', textAlign: 'right' }}>
                {h.address && <div>{h.address}</div>}
                {h.phone && <div>Tel: {h.phone}</div>}
                {h.email && <div>{h.email}</div>}
              </div>
            </div>
          </div>
        ) : (
          // Classic: full colored header bar
          <div className="report-header" style={{ backgroundColor: c }}>
            <div className="report-header-inner">
              <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                {h.logoUrl ? (
                  <img src={h.logoUrl} alt="" style={{ height: 48, width: 48, objectFit: 'contain', borderRadius: 6 }} />
                ) : (
                  <div style={{ width: 48, height: 48, borderRadius: 6, backgroundColor: 'rgba(255,255,255,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontWeight: 700, fontSize: 20, flexShrink: 0 }}>
                    {h.hospitalName.charAt(0)}
                  </div>
                )}
                <div>
                  <h1 style={{ color: 'white', fontWeight: 700, fontSize: '18px', letterSpacing: '0.5px', lineHeight: 1.2, margin: 0 }}>
                    {h.hospitalName.toUpperCase()}
                  </h1>
                  {h.tagline && <p style={{ color: 'rgba(255,255,255,0.7)', fontSize: '10px', letterSpacing: '1.5px', textTransform: 'uppercase', marginTop: 2 }}>{h.tagline}</p>}
                </div>
              </div>
              <div style={{ textAlign: 'right', color: 'rgba(255,255,255,0.8)', fontSize: '9px', lineHeight: 1.6, maxWidth: 220 }}>
                {h.address && <div>{h.address}</div>}
                {h.phone && <div>Tel: {h.phone}</div>}
                {h.email && <div>{h.email}</div>}
                {h.website && <div>{h.website}</div>}
              </div>
            </div>
          </div>
        )}

        {/* === STUDY TITLE === */}
        {!isCompact && (
          <div className="report-study-title">
            <span className="report-modality-badge" style={{ backgroundColor: c }}>
              {report.modality} {report.bodyRegion}
            </span>
            <h2 className="report-title-text">
              {report.bodyRegion} — {report.studyType}
            </h2>
            {report.contrastAdministered && (
              <span className="report-contrast-badge">+ Contrast</span>
            )}
          </div>
        )}

        {/* === PATIENT INFO === */}
        {isCompact ? (
          <div style={{ margin: '6px 20px', padding: '6px 12px', border: `1px solid #e5e7eb`, borderRadius: 3, fontSize: '9pt', display: 'grid', gridTemplateColumns: `repeat(${cols}, 1fr)`, gap: 3 }}>
            <div><span style={{ color: '#6b7280', fontSize: '7pt', textTransform: 'uppercase' }}>Patient</span><p style={{ fontWeight: 600 }}>{report.patientName}{report.patientAge ? `, ${report.patientAge}y` : ''}{report.patientGender ? ` / ${report.patientGender}` : ''}</p></div>
            <div><span style={{ color: '#6b7280', fontSize: '7pt', textTransform: 'uppercase' }}>Ref.</span><p>{report.referringDoctor || '—'}</p></div>
            <div><span style={{ color: '#6b7280', fontSize: '7pt', textTransform: 'uppercase' }}>Date</span><p>{report.studyDate ? format(new Date(report.studyDate), 'dd MMM yyyy') : '—'}</p></div>
            {report.patientId && <div><span style={{ color: '#6b7280', fontSize: '7pt', textTransform: 'uppercase' }}>ID</span><p style={{ fontFamily: 'monospace', fontSize: '8pt' }}>{report.patientId}</p></div>}
            {report.accessionNumber && <div><span style={{ color: '#6b7280', fontSize: '7pt', textTransform: 'uppercase' }}>Acc#</span><p style={{ fontFamily: 'monospace', fontSize: '8pt' }}>{report.accessionNumber}</p></div>}
          </div>
        ) : (
          <div className="report-patient-box">
            <div className="report-patient-grid" style={{ gridTemplateColumns: `repeat(${cols}, 1fr)` }}>
              <div className="report-patient-field">
                <span className="report-patient-label">Patient Name</span>
                <span className="report-patient-value font-semibold">{report.patientName}</span>
              </div>
              <div className="report-patient-field">
                <span className="report-patient-label">Age / Gender</span>
                <span className="report-patient-value">
                  {report.patientAge && `${report.patientAge} yrs`}
                  {report.patientAge && report.patientGender && ' / '}
                  {report.patientGender}
                </span>
              </div>
              {report.patientId && (
                <div className="report-patient-field">
                  <span className="report-patient-label">Patient ID</span>
                  <span className="report-patient-value font-mono text-xs">{report.patientId}</span>
                </div>
              )}
              <div className="report-patient-field">
                <span className="report-patient-label">Study Date</span>
                <span className="report-patient-value">
                  {report.studyDate ? format(new Date(report.studyDate), 'dd MMM yyyy') : '—'}
                </span>
              </div>
              {report.referringDoctor && (
                <div className="report-patient-field">
                  <span className="report-patient-label">Referring Physician</span>
                  <span className="report-patient-value">{report.referringDoctor}</span>
                </div>
              )}
              <div className="report-patient-field">
                <span className="report-patient-label">Accession No.</span>
                <span className="report-patient-value font-mono text-xs">{report.accessionNumber || '—'}</span>
              </div>
            </div>
          </div>
        )}

        {/* === CLINICAL INFO === */}
        {h.showClinicalInfo && (report.clinicalIndication || report.clinicalHistory) && (
          <div className="report-section">
            <div className="report-patient-box">
              <div className="report-patient-grid" style={{ gridTemplateColumns: `repeat(${cols}, 1fr)` }}>
                {report.clinicalIndication && (
                  <div className="report-patient-field col-span-full">
                    <span className="report-patient-label">Clinical Indication</span>
                    <span className="report-patient-value">{report.clinicalIndication}</span>
                  </div>
                )}
                {report.clinicalHistory && (
                  <div className="report-patient-field col-span-full">
                    <span className="report-patient-label">Clinical History</span>
                    <span className="report-patient-value">{report.clinicalHistory}</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* === TECHNIQUE === */}
        {h.showTechnique && report.technique && (
          <div className="report-section">
            <h3 className="report-section-heading">Technique</h3>
            <p className="report-body-text">{report.technique}</p>
          </div>
        )}

        {/* === COMPARISON === */}
        {h.showComparison && report.comparison && (
          <div className="report-section">
            <h3 className="report-section-heading">Comparison</h3>
            <p className="report-body-text">{report.comparison}</p>
          </div>
        )}

        {/* === FINDINGS === */}
        {renderFindings()}

        {/* === IMPRESSION === */}
        {renderImpression()}

        {/* === FOOTER === */}
        <div className="report-footer">
          {!isCompact && <div className="report-footer-bar" style={{ backgroundColor: c }} />}

          <div className="report-footer-content" style={{ padding: isCompact ? '6px 20px 2px' : '12px 28px 4px' }}>
            {h.showSignature && h.radiologistName && (
              <div className="report-signature-area">
                <div className="report-signature-block">
                  {!isCompact && <div className="report-signature-line" />}
                  <p className="report-signature-name">{h.radiologistName}</p>
                  {h.radiologistQualification && <p className="report-signature-qual">{h.radiologistQualification}</p>}
                  {h.radiologistRegNumber && <p className="report-signature-reg">Reg. No: {h.radiologistRegNumber}</p>}
                </div>
              </div>
            )}
            <div className="report-footer-meta">
              {h.showAccreditation && h.accreditation && (
                <p className="report-accreditation">
                {h.accreditation}{h.accreditationNumber ? ` — ${h.accreditationNumber}` : ''}
              </p>
              )}
              <p className="report-timestamp">
                Report generated: {format(new Date(report.createdAt), 'dd MMM yyyy, hh:mm a')}
              </p>
              {report.reportNumber && (
                <p className="report-number">Report No: {report.reportNumber}</p>
              )}
            </div>
          </div>

          {h.showFooterMessage && (
            <div className="report-thank-you" style={{ color: c, padding: isCompact ? '4px 0 8px' : '6px 0 12px' }}>
              {h.footerMessage.toUpperCase()}
            </div>
          )}
        </div>
      </div>
    </>
  );
}